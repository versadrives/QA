📁 CF NO-LOAD TESTING/
├── 📄 app.py                    (your main Flask app)
├── 📄 run\_app.py               (your webview launcher)
├── 📄 rs485\_reader.py          (your sensor module)
├── 📄 requirements.txt         (Python dependencies)
├── 📄 CF NO-LOAD TESTER.bat        (the portable launcher)
├── 📄 scan\_log.db             (database - optional)
├── 📁 templates/               (your HTML templates)
│   └── 📄 index.html
├── 📁 static/                  (CSS, JS, images)
│   ├── 📄 style.css
│   └── 📄 script.js
└── 📄 README.txt              (instructions for users)



CF NO-LOAD TESTER - Portable Version

SYSTEM REQUIREMENTS:

* Windows 10 or later
* Python 3.11+ installed with "Add to PATH" option checked

INSTALLATION:

1. Copy this entire folder to any location on your computer
2. Double-click "CF NO-LOAD TESTER.bat" to run the application
3. The application will open in a new window automatically

FIRST TIME SETUP:

* The batch file will automatically install required Python packages
* This may take a few minutes on first run
* Internet connection required for first-time setup

USAGE:

* Double-click "CF NO-LOAD TESTER" to start
* Application opens in its own window
* Close the command window to stop the application

TROUBLESHOOTING:

* If Python not found: Install Python from Microsoft STORE
* If app doesn't start: Check that all files are in the same folder
* If browser needed: Go to http://localhost:5000
